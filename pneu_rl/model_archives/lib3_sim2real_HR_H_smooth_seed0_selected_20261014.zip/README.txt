Selected lib3 sim2real model assets

Each model folder contains one model.pth, original cfg.yaml and infos.pkl.
model.pth is copied from the selected checkpoint listed in model_selection.json.
Use the default model.pth loader; do not pass --checkpoint-episode for this package.
Extract into the repository root to retain the pneu_rl/models and reference paths.
Zero-shot: load_model(path=..., evaluate=True).
Fresh-data fine-tuning: load(name=..., train=True, load_buffer=False).
If using set_retrain, pass load_buffer=False and copy_buffer=False.
Intermediate checkpoints and replay buffers are omitted.
The original workspace model folders are unchanged.
This package contains model assets, not a corrected real-hardware launcher.
